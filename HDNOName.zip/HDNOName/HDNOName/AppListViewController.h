//
//  AppListViewController.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "BaseViewController.h"

@interface AppListViewController : BaseViewController {
    NSMutableArray *_dataAry;
    UITableView *_tableView;
}

@property (nonatomic, copy) NSString *requestURL;
@property (nonatomic, copy) NSString *categoryViewType;

- (void)lodingData:(NSString *)url isMore:(BOOL)isMore;

@end
