//
//  AppListViewController.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "AppListViewController.h"
#import "UIView+Common.h"
#import <JSONModel/JSONModel.h>
#import <AFNetworking.h>
#import <MBProgressHUD/MBProgressHUD.h>
#import <MJRefresh/MJRefresh.h>
#import "FreeAllDefine.h"
#import "AppModel.h"
#import "AppViewCell.h"
#import "SubjectModel.h"
#import "SearchViewController.h"
#import "NSString+Tools.h"
#import "CategoryViewController.h"
#import "SubjectTableViewCell.h"
#import "DetailViewController.h"
#import "JWCache.h"
#import "SetViewController.h"

@interface AppListViewController () <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate> {
    AFHTTPRequestOperationManager *_manager;
    NSString *_categoryID;
    BOOL _isCache;
}

@end

@implementation AppListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _isCache = NO;
    _categoryID = @"0";
    [self initialAllObj];
}

/**
 *  初始化所有数据
 */
- (void)initialAllObj {
    _dataAry = [NSMutableArray array];
    [self initRequestManager];
    [self createTableView];
    [self initBarButtonItems];
}

/**
 *  初始化 导航按钮
 */
- (void)initBarButtonItems {
    [self createBarButtonItemWithBackground:@"buttonbar_action" Frame:CGRectMake(0, 0, 43, 30) title:@"分类" aSelector:@selector(buttonActionLeft:) isLeft:YES];
    
    [self createBarButtonItemWithBackground:@"buttonbar_action" Frame:CGRectMake(0, 0, 43, 30) title:@"设置" aSelector:@selector(buttonActionRight:) isLeft:NO];
}

// 导航左键点击方法
- (void)buttonActionLeft:(UIButton *)button {
    CategoryViewController *categoryVC = [CategoryViewController new];
    [categoryVC setCategoryIdBlock:^(NSString *categoryId) {
        _categoryID = categoryId;
        [_tableView.header beginRefreshing];
    }];
    
    categoryVC.title = @"分类";
    categoryVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:categoryVC animated:YES];
}
// 导航右键点击方法
- (void)buttonActionRight:(UIButton *)button {
    SetViewController *setViewC = [[SetViewController alloc] init];
    
    [self.navigationController pushViewController:setViewC animated:YES];
}

// initRequestManager
- (void)initRequestManager {
    if (_manager == nil) {
        _manager = [AFHTTPRequestOperationManager manager];
        [_manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
        _manager.requestSerializer.timeoutInterval = 10.f;
        [_manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
        _manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    }
}


/**
 *  创建表视图
 */
- (void)createTableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, [self.view width], [self.view height] - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        //???:what
        if ([_categoryViewType isEqualToString:kSubjectType]) {
            [_tableView registerClass:[SubjectTableViewCell class] forCellReuseIdentifier:@"subCell"];
            _tableView.allowsSelection = NO;
        } else {
            [_tableView registerClass:[AppViewCell class] forCellReuseIdentifier:@"appCell"];
        }
        
        [self.view addSubview:_tableView];
    }
    
    // 添加搜索
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, [_tableView width], 44.0)];
    searchBar.placeholder = @"60万应用,have a loke";
    searchBar.delegate = self;
    
    _tableView.tableHeaderView = searchBar;
    
    // 添加 刷新
    MJRefreshNormalHeader *refreshHeader = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self prepareLoadData:NO];
    }];
    
    MJRefreshBackNormalFooter *refreshFooter = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self prepareLoadData:YES];
    }];
    
    _tableView.header = refreshHeader;
    _tableView.footer = refreshFooter;
    
    
    [refreshHeader beginRefreshing];
}

#pragma mark -
#pragma mark searchBar协议
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    searchBar.text = @"";
    [searchBar resignFirstResponder];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
    [searchBar setShowsCancelButton:YES animated:YES];
    
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
    [searchBar setShowsCancelButton:NO animated:YES];
    
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    SearchViewController *searchView = [SearchViewController new];
    
    if ([_categoryViewType isEqualToString:kHotType]) {
        searchView.requestURL = SEARCH_HOT_URL;
    } else if ([_categoryViewType isEqualToString:kLimitType]) {
        searchView.requestURL = SEARCH_LIMIT_URL;
    } else if ([_categoryViewType isEqualToString:kReduceType]) {
        searchView.requestURL = SEARCH_REDUCE_URL;
    } else if ([_categoryViewType isEqualToString:kFreeType]) {
        searchView.requestURL = SEARCH_FREE_URL;
    }
    
    // 搜索编码
    searchView.searchText = URLEncodedString(searchBar.text);
    
    searchView.title = @"搜索结果";
    
    // 跳转之后隐藏 tabBar
    searchView.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:searchView animated:YES];
    [searchBar resignFirstResponder];
    searchBar.text = @"";
}

#pragma mark -
#pragma mark RequestData
- (void)prepareLoadData:(BOOL)isMore {
    NSString *url = _requestURL;
    NSInteger page = 1;
    if (isMore) {
        page = _dataAry.count / 10 + 1;
    }
    
    if ([_categoryViewType isEqualToString:kHotType]) {
        url = [NSString stringWithFormat:_requestURL, page];
    } else if ([_categoryViewType isEqualToString:kSubjectType]) {
        url = [NSString stringWithFormat:_requestURL, page];
    } else {
        url = [NSString stringWithFormat:_requestURL, page, _categoryID];
    }
    
    [self lodingData:url isMore:isMore];
}

- (void)lodingData:(NSString *)url isMore:(BOOL)isMore {
    // 添加刷新菊花
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    // 请求数据
    
    NSData *cacheData = [JWCache objectForKey:MD5Hash(url)];
    if (cacheData && !_isCache) {
        _isCache = YES;
        NSLog(@"cache");
        AppModel *appModel = nil;
        
        if ([_categoryViewType isEqualToString:kSubjectType]) {
            NSArray *arySub = [NSJSONSerialization JSONObjectWithData:cacheData options:NSJSONReadingMutableLeaves error:nil];
            NSMutableDictionary *dictSub = [NSMutableDictionary dictionary];
            [dictSub setObject:arySub forKey:@"subject"];
            
            SubjectModel *subModel = [[SubjectModel alloc] initWithDictionary:dictSub error:nil];
            if (!isMore) {
                [_dataAry removeAllObjects];
            }
            [_dataAry addObjectsFromArray:subModel.subject];
            
        } else {
            // 解析数据
            appModel = [[AppModel alloc] initWithData:cacheData error:nil];
            if (!isMore) {
                [_dataAry removeAllObjects];
            }
            [_dataAry addObjectsFromArray:appModel.applications];
        }
        
        [_tableView reloadData];
        // 关闭刷新提示
        !isMore ? [_tableView.header endRefreshing] :[_tableView.footer endRefreshing];
        // 隐藏刷新菊花
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        
    } else {
        NSLog(@"new");
        [_manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            AppModel *appModel = nil;
            
            if ([_categoryViewType isEqualToString:kSubjectType]) {
                NSArray *arySub = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
                NSMutableDictionary *dictSub = [NSMutableDictionary dictionary];
                [dictSub setObject:arySub forKey:@"subject"];
                
                SubjectModel *subModel = [[SubjectModel alloc] initWithDictionary:dictSub error:nil];
                if (!isMore) {
                    [_dataAry removeAllObjects];
                }
                [_dataAry addObjectsFromArray:subModel.subject];
                
            } else {
                // 解析数据
                appModel = [[AppModel alloc] initWithData:responseObject error:nil];
                if (!isMore) {
                    [_dataAry removeAllObjects];
                }
                [_dataAry addObjectsFromArray:appModel.applications];
            }
            
            [_tableView reloadData];
            // 关闭刷新提示
            !isMore ? [_tableView.header endRefreshing] :[_tableView.footer endRefreshing];
            // 隐藏刷新菊花
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            // 初始 类别ID
            _categoryID = @"0";
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [JWCache setObject:responseObject forKey:MD5Hash(url)];
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            // 关闭刷新提示
            !isMore ? [_tableView.header endRefreshing] :[_tableView.footer endRefreshing];
            NSLog(@"%@", [error description]);
            // 隐藏刷新菊花
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }];
    }
    
}

#pragma mark -
#pragma mark tableView 协议
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([_categoryViewType isEqualToString:kSubjectType]) {
        return 350;
    } else {
        return 110;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _dataAry.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if ([self.categoryViewType isEqualToString:kSubjectType]) {
        SubjectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"subCell" forIndexPath:indexPath];
        
        cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"topic_Cell_Bg"]];
        
        // cell block
        cell.subItemBlock = ^(NSString *subId) {
            DetailViewController *detailViewController = [DetailViewController new];
            detailViewController.applicationId = subId;
            
            detailViewController.title = @"应用详情页";
            
            detailViewController.hidesBottomBarWhenPushed = YES;
            
            [self.navigationController pushViewController:detailViewController animated:YES];
            
        };
        cell.backgroundView.frame = CGRectMake(10, 10, widthFromFrame(self.view.frame) - 20, heightFromFrame(self.view.frame) - 20);
        
        SubjectItems *item = _dataAry[indexPath.row];
        cell.model = item;
        
        return cell;
    } else {
        AppViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"appCell" forIndexPath:indexPath];
        
        [cell setSelectedBackgroundView:[[UIImageView alloc] initWithImage:nil highlightedImage:[UIImage imageNamed:@"appproduct_loadingviewcell_ligh_2t"]]];
        
        if (indexPath.row % 2 == 0) {
            cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cate_list_bg1"]];
        } else {
            cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cate_list_bg2"]];
        }
        
        cell.model = _dataAry[indexPath.row];
        
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    ApplicationModel *model = _dataAry[indexPath.row];
    
    DetailViewController *detail = [DetailViewController new];
    
    detail.title = @"应用详情";
    
    detail.hidesBottomBarWhenPushed = YES;
    
    detail.applicationId = model.applicationId;
    
    [self.navigationController pushViewController:detail animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
