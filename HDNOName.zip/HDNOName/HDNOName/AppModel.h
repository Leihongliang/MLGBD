//
//  AppModel.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "JSONModel.h"

@protocol ApplicationModel
@end
@interface ApplicationModel : JSONModel

@property (nonatomic, copy) NSString<Optional> *applicationId;
@property (nonatomic, copy) NSString<Optional> *slug;
@property (nonatomic, copy) NSString<Optional> *name;
@property (nonatomic, copy) NSString<Optional> *releaseDate;
@property (nonatomic, copy) NSString<Optional> *version;
@property (nonatomic, copy) NSString<Optional> *myDescription;
@property (nonatomic, copy) NSString<Optional> *categoryId;
@property (nonatomic, copy) NSString<Optional> *categoryName;
@property (nonatomic, copy) NSString<Optional> *iconUrl;
@property (nonatomic, copy) NSString<Optional> *itunesUrl;
@property (nonatomic, copy) NSString<Optional> *starCurrent;
@property (nonatomic, copy) NSString<Optional> *starOverall;
@property (nonatomic, copy) NSString<Optional> *downloads;
@property (nonatomic, copy) NSString<Optional> *currentPrice;
@property (nonatomic, copy) NSString<Optional> *lastPrice;
@property (nonatomic, copy) NSString<Optional> *priceTrend;
@property (nonatomic, copy) NSString<Optional> *expireDatetime;
@property (nonatomic, copy) NSString<Optional> *releaseNotes;
@property (nonatomic, copy) NSString<Optional> *updateDate;
@property (nonatomic, copy) NSString<Optional> *fileSize;
@property (nonatomic, copy) NSString<Optional> *ipa;
@property (nonatomic, copy) NSString<Optional> *shares;
@property (nonatomic, copy) NSString<Optional> *favorites;
@property (nonatomic, copy) NSString<Optional> *ratingOverall;

@end

@interface AppModel : JSONModel

@property (nonatomic, strong) NSMutableArray<ApplicationModel> *applications;

@end
