//
//  AppViewCell.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppModel.h"

@interface AppViewCell : UITableViewCell

@property (nonatomic, strong) ApplicationModel *model;

@end
