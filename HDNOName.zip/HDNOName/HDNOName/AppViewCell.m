//
//  AppViewCell.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "AppViewCell.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "UIView+Common.h"
#import "IStarsView.h"
#import "HDHelper.h"

@interface AppViewCell() {
    UIImageView *_appIconImageView;
    UILabel *_titleLabel;
    UILabel *_expireDatetime;
    UILabel *_priceLabel;
    UILabel *_categoryLabel;
    UILabel *_separateLine;
    UILabel *_appType;
    UILabel *_shareLabel;
    IStarsView *_iStarsView;
    
}

@end

@implementation AppViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self customCell];
    }
    return self;
}

- (void)customCell {
    _appIconImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _appIconImageView.layer.cornerRadius = 16;
    _appIconImageView.clipsToBounds = YES;
    [self.contentView addSubview:_appIconImageView];

    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.font = [UIFont boldSystemFontOfSize:17];
    _titleLabel.textColor = [UIColor colorWithRed:30/255.0 green:30/255.0 blue:30/255.0 alpha:1];
    [self.contentView addSubview:_titleLabel];
    
    _expireDatetime = [[UILabel alloc] initWithFrame:CGRectZero];
    _expireDatetime.font = [UIFont boldSystemFontOfSize:14];
    _expireDatetime.textColor = [UIColor colorWithRed:146/255.0 green:146/255.0 blue:146/255.0 alpha:1];
    [self.contentView addSubview:_expireDatetime];
    
    _priceLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _priceLabel.font = [UIFont boldSystemFontOfSize:14];
    _priceLabel.textColor = [UIColor colorWithRed:146/255.0 green:146/255.0 blue:146/255.0 alpha:1];
    _priceLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:_priceLabel];
    
    _categoryLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _categoryLabel.textColor = [UIColor colorWithRed:146/255.0 green:146/255.0 blue:146/255.0 alpha:1];
    [self.contentView addSubview:_categoryLabel];
    
    _separateLine = [[UILabel alloc] initWithFrame:CGRectZero];
    _separateLine.layer.borderWidth = 1;
    _separateLine.layer.borderColor = [[UIColor colorWithRed:146/255.0 green:146/255.0 blue:146/255.0 alpha:1] CGColor];
    [self.contentView addSubview:_separateLine];
    
    _shareLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _shareLabel.font = [UIFont boldSystemFontOfSize:14];
    _shareLabel.textColor = [UIColor colorWithRed:146/255.0 green:146/255.0 blue:146/255.0 alpha:1];
    [self.contentView addSubview:_shareLabel];
    
    _iStarsView = [IStarsView new];
    [self.contentView addSubview:_iStarsView];
    
    _appType = [UILabel new];
    _appType.textAlignment = NSTextAlignmentCenter;
    _appType.textColor = [UIColor colorWithRed:146/255.0 green:146/255.0 blue:146/255.0 alpha:1];
    [self.contentView addSubview:_appType];
}

- (void)setModel:(ApplicationModel *)model {
    _model = model;
    [self reloadCell];
}

- (void)reloadCell {
    [_appIconImageView sd_setImageWithURL:[NSURL URLWithString:_model.iconUrl] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    _titleLabel.text = _model.name;
    
    NSDateFormatter *df = [NSDateFormatter new];
    df.dateFormat = @"yyyy-MM-dd HH:mm:ss.0";
    _expireDatetime.text = [NSString stringWithFormat:@"剩余: %@", [HDHelper dateToNowFromString:_model.expireDatetime dateFormatter:df]];
    
    _priceLabel.text = [NSString stringWithFormat:@"￥ %.1f", [_model.lastPrice floatValue]];
    
    [_iStarsView setLevel:[_model.starCurrent doubleValue]];
    
    _appType.text = @"游戏";
    
    _shareLabel.text = [NSString stringWithFormat:@"分享: %@ 次    收藏: %@ 次   下载: %@次", _model.shares, _model.favorites, _model.downloads];
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat leftMargin = 15;
    CGFloat topMargin = 10;
    
    _appIconImageView.frame = CGRectMake(leftMargin, topMargin, 70, 70);
    
    _titleLabel.frame = CGRectMake(maxX(_appIconImageView) + 15, minY(_appIconImageView) - 1, widthFromFrame(self.frame) - 130, 18);
    
    _expireDatetime.frame = CGRectMake(minX(_titleLabel), maxY(_titleLabel) + 7, 114, 16);
    
    _priceLabel.frame = CGRectMake(widthFromFrame(self.frame) - 90, minY(_expireDatetime), 50, 16);

    _separateLine.frame = CGRectMake(0, 0, widthFromFrame(_priceLabel.frame), 1);
    _separateLine.center = _priceLabel.center;
    
    _iStarsView.frame = CGRectMake(minX(_expireDatetime), maxY(_expireDatetime) + 10, 65, 23);
    
    _appType.center = CGPointMake(_priceLabel.center.x, _iStarsView.center.y);
    
    _shareLabel.frame = CGRectMake(leftMargin + 3, maxY(_appIconImageView) + 8, widthFromFrame(self.frame) - 2*leftMargin, 16);
}


@end
//





































//