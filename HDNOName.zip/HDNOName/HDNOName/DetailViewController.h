//
//  DetailViewController.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (nonatomic, copy) NSString *appID;

@property (nonatomic, copy) NSString *applicationId;

@end
