//
//  DetailViewController.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "DetailViewController.h"
#import "UIView+Common.h"
#import <UIImageView+WebCache.h>
#import <AFNetworking.h>
#import "FreeAllDefine.h"
#import "DetailModel.h"
#import <UIButton+WebCache.h>
#import "NearApplicationModel.h"
#import "DBManager.h"
#import <MessageUI/MessageUI.h>
#import "PhotoViewController.h"
#import "HDHelper.h"

@interface DetailViewController () <UIActionSheetDelegate, MFMessageComposeViewControllerDelegate, MFMailComposeViewControllerDelegate> {
    UIScrollView *_bottomScrollView;
    UIImageView *_appIcon;
    UILabel *_titleLabel;
    UILabel *_priceLabel;
    UILabel *_typeLabel;
    UIScrollView *_appShutScreenSV;
    UILabel *_detailLabel;
    DetailModel *_appDetailModel;
    NSMutableArray *_nearsArray;
    UIScrollView *_nearsScrollView;
    UIImageView *_detailImgView;
    BOOL _isFavourite;
//    NSInteger _viewHeight;
}

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
//    _viewHeight = 0;
    
    [self createBarButtonItemWithBackground:@"buttonbar_back" Frame:CGRectMake(0, 0, 45, 28) title:@"返回" aSelector:@selector(leftBtnClick:) isLeft:YES];
    
    [self addTitleWithName:@"应用详情"];
    // 设置背景颜色，以防跳转卡顿
    self.view.backgroundColor = [UIColor whiteColor];
    [self loadAppDetailData];
    [self createDetailViews];
}

- (void)leftBtnClick:(UIBarButtonItem *)barBtn {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

/**
 *  给导航设置title
 *
 */
- (void)addTitleWithName:(NSString *)name {
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 400)];
    titleLabel.text = name;
    titleLabel.textColor = [UIColor colorWithRed:30/255.f green:160/255.f blue:230/255.f alpha:1];
    titleLabel.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:22];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    self.navigationItem.titleView = titleLabel;
}

- (void)loadAppDetailData {
    _nearsArray = [NSMutableArray array];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *url = [NSString stringWithFormat:kDetailUrl, _applicationId];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        _appDetailModel = [[DetailModel alloc] initWithData:responseObject error:nil];
        [self refreshUI];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@", [error description]);
    }];
    
    
}

- (void)refreshUI {
    [_appIcon sd_setImageWithURL:[NSURL URLWithString:_appDetailModel.iconUrl] placeholderImage:[UIImage imageNamed:@"icon"]];
    _titleLabel.text = _appDetailModel.name;
    
    NSString *string = @"";
    
    if ([_appDetailModel.priceTrend isEqualToString:@"limited"]) {
        string = @"限免中";
    }else if ([_appDetailModel.priceTrend isEqualToString:@"sales"]) {
        string = @"降价中";
    }else if ([_appDetailModel.priceTrend isEqualToString:@"free"]) {
        string = @"免费中";
    }
    _priceLabel.text = [NSString stringWithFormat:@"原价:￥%@.00  %@  %@MB",_appDetailModel.lastPrice,string,_appDetailModel.fileSize];
    
    _typeLabel.text = [NSString stringWithFormat:@"类型:%@     评分:%@",_appDetailModel.categoryName,_appDetailModel.starCurrent];
    
    NSInteger photosCount = _appDetailModel.photos.count;
    CGFloat btnWidth =  (widthFromFrame(_appShutScreenSV.frame) - 5*4) / 5.0;
    
    for (int i = 0; i < photosCount; i ++) {
        PhotoModel *photo = _appDetailModel.photos[i];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(i *btnWidth + i *5, 0, btnWidth, 80);
        [button sd_setBackgroundImageWithURL:[NSURL URLWithString:photo.smallUrl] forState:UIControlStateNormal];
        button.tag = 3000 + i;
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [_appShutScreenSV addSubview:button];
    }
    _appShutScreenSV.delaysContentTouches = NO;
    _appShutScreenSV.contentSize = CGSizeMake(photosCount * btnWidth + (photosCount - 1) * 5, 80);
    
    _detailLabel.frame = CGRectMake(15, maxY(_appShutScreenSV) + 10, widthFromFrame(_detailImgView.frame) - 30, [HDHelper textHeightFromTextString:_appDetailModel.descrip width:widthFromFrame(_detailImgView.frame) - 30 fontSize:13]);
    _detailLabel.text = _appDetailModel.descrip;
    
    
    _detailImgView.frame = CGRectMake(10, 10, widthFromFrame(self.view.frame) - 20, heightFromFrame(_detailLabel.frame) + 240);
    
    _bottomScrollView.contentSize = CGSizeMake(widthFromFrame(_bottomScrollView.frame), heightFromFrame(_detailLabel.frame) + 360);
    
    [self applicationIsFavourite];
    [self loadNearApps];
}

- (void)buttonClick:(UIButton *)button {
    PhotoViewController *photoViewC = [[PhotoViewController alloc] init];
    photoViewC.photoIndex = button.tag - 3000;
    photoViewC.photos = _appDetailModel.photos;
    photoViewC.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:photoViewC animated:YES];
    
}

- (void)createDetailViews {
    CGFloat leftMargin = 10;
//    CGFloat topMargin = 10;
    
    _bottomScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, widthFromFrame(self.view.frame), heightFromFrame(self.view.frame) - 64 - 44)];
    [self.view addSubview:_bottomScrollView];
    
    _detailImgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, widthFromFrame(self.view.frame) - 20, 480)];
    _detailImgView.userInteractionEnabled = YES;
    _detailImgView.image = [[UIImage imageNamed:@"appdetail_background"] stretchableImageWithLeftCapWidth:15 topCapHeight:15];
    // 立即响应 scrollView 上的事件
    _bottomScrollView.delaysContentTouches = NO;
    [_bottomScrollView addSubview:_detailImgView];
    
    // 创建 appIcon
    _appIcon = [[UIImageView alloc] initWithFrame:CGRectMake(leftMargin, 15, 57, 57)];
    _appIcon.layer.cornerRadius = 10;
    _appIcon.layer.borderColor = [[UIColor whiteColor] CGColor];
    _appIcon.layer.borderWidth = 1;
    // 切图
    _appIcon.layer.masksToBounds = YES;
    [_detailImgView addSubview:_appIcon];
    
    // 创建 titleLabel
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(maxX(_appIcon) + 10, minY(_appIcon) - 5, widthFromFrame(_detailImgView.frame) - 90, 22)];
    _titleLabel.font = [UIFont boldSystemFontOfSize:19];
    _titleLabel.textColor = [UIColor colorWithRed:59/255.0 green:59/255.0 blue:59/255.0 alpha:1];
    [_detailImgView addSubview:_titleLabel];
    
    // priceLabel
    _priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(minX(_titleLabel), maxY(_titleLabel) + 5, widthFromFrame(_titleLabel.frame), 17)];
    _priceLabel.font = [UIFont systemFontOfSize:15];
    _priceLabel.textColor = [UIColor lightGrayColor];
    [_detailImgView addSubview:_priceLabel];
    
    // typeLabel
    _typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(minX(_titleLabel), maxY(_priceLabel) + 5, widthFromFrame(_titleLabel.frame), 17)];
    _typeLabel.font = [UIFont systemFontOfSize:15];
    _typeLabel.textColor = [UIColor lightGrayColor];
    [_detailImgView addSubview:_typeLabel];
    
    // button
    CGFloat buttonWidth = (widthFromFrame(_detailImgView.frame) - 3) / 3.0;
    NSArray *buttonTitleArray = @[@"分享", @"收藏", @"下载"];
    for (int i = 0; i < 3; i ++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(i * buttonWidth + 1, maxY(_appIcon) + 10, buttonWidth, 45);
        [button setTitleColor:[UIColor colorWithRed:81/255.0 green:98/255.0 blue:139/255.0 alpha:1] forState:UIControlStateNormal];
        button.tag = 1000 + i;
        if (i == 0) {
            [button setBackgroundImage:[UIImage imageNamed:@"Detail_btn_left"] forState:UIControlStateNormal];
        } else if (i == 1) {
            [button setBackgroundImage:[UIImage imageNamed:@"Detail_btn_middle"] forState:UIControlStateNormal];
        } else if (i == 2) {
            [button setBackgroundImage:[UIImage imageNamed:@"Detail_btn_right"] forState:UIControlStateNormal];
        }
        [button setTitle:buttonTitleArray[i] forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont boldSystemFontOfSize:17];
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [_detailImgView addSubview:button];
    }
    //@"appproduct_loadingviewcell_ligh_2t"
    _appShutScreenSV = [[UIScrollView alloc] initWithFrame:CGRectMake(10, maxY(_appIcon) + 45 + 5 + 15, widthFromFrame(_detailImgView.frame) - 10 * 2, 80)];
    [_detailImgView addSubview:_appShutScreenSV];
    
    _detailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _detailLabel.numberOfLines = 0;
    _detailLabel.font = [UIFont systemFontOfSize:13];
    _detailLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
    [_detailImgView addSubview:_detailLabel];
}

- (void)applicationIsFavourite {
    // 查找是否处于收藏状态
    _isFavourite = [[DBManager sharedManager] isExistAppForAppId:_appDetailModel.applicationId recordType:@"favorites"];
    if (_isFavourite) {
        UIButton *button = (UIButton *)[_detailImgView viewWithTag:1001];
        [button setTitle:@"已收藏" forState:UIWindowLevelNormal];
        button.backgroundColor = [UIColor lightGrayColor];
        button.enabled = NO;
    }
}

- (void)buttonAction:(UIButton *)button {
    
    NSInteger btnTag = button.tag - 1000;
    if (btnTag == 1) {
        if (_isFavourite) {
            return;
        }
        [[DBManager sharedManager] insertModel:_appDetailModel recordType:@"favorites"];
        [self applicationIsFavourite];
    } else if (btnTag == 2) {
        //保存下载记录
        if (!_appDetailModel) {
            return;
        }
        //有 才 保存
        [[DBManager sharedManager] insertModel:_appDetailModel recordType:@"downloads"];
        //调用 系统的app
        //点击下载 调用 AppStore
        //- openURL:
        //
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:_appDetailModel.itunesUrl]];
    } else {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"分享" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"邮件", @"短信", nil];
        [actionSheet showInView:self.view];
    }
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSLog(@"%ld", buttonIndex);
    if (buttonIndex) {
        if ([MFMessageComposeViewController canSendText]) {
            MFMessageComposeViewController *message = [[MFMessageComposeViewController alloc] init];
            
            message.recipients = @[@"10086", @"1511"];
            
            message.body = [NSString stringWithFormat:@"hello man, please down %@", _appDetailModel.itunesUrl];
            
            //如果要处理发送的状态 要设置代理
            message.messageComposeDelegate = self;
            
            
            //模态跳转(内部有导航)
            [self presentViewController:message animated:YES completion:nil];
            
        } else {
            NSLog(@"不支持短信发送");
        }
    } else {
        //方法1:可以调用系统邮箱app
        //[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"mailto://421051332@qq.com"]];
        //方法2: 跳转到具有邮箱功能的界面
        if ([MFMailComposeViewController canSendMail]) {
            //检测是否支持邮箱功能
            //如果支持 创建界面
            MFMailComposeViewController *mail = [[MFMailComposeViewController alloc] init];
            //设置联系人
            [mail setToRecipients:@[@"hdclearly@163.com",@"zhengzhou1507@163.com"]];
            //设置抄送
            [mail setCcRecipients:@[@"xxx@sina.com"]];
            //设置标题
            [mail setSubject:@"分享爱限免应用"];
            //设置内容
            NSString *str = [NSString stringWithFormat:@"点击有惊喜:%@", _appDetailModel.itunesUrl];
            //第二个参数 是否以HTML格式
            [mail setMessageBody:str isHTML:YES];
            
            //添加附件
            NSData *data = UIImagePNGRepresentation([UIImage imageNamed: @"account_candou"]);
            //第一个参数 文件二进制  2 文件的类型 3  文件的名字
            [mail addAttachmentData:data mimeType:@"image/png" fileName:@"account_candou"];
            
            //设置代理
            mail.mailComposeDelegate = self;
            //模态跳转
            [self presentViewController:mail animated:YES completion:nil];
        }
    }
}

#pragma mark - 邮箱协议
/*
 MFMailComposeResultCancelled,
 MFMailComposeResultSaved,
 MFMailComposeResultSent,
 MFMailComposeResultFailed
 */
//发送邮件之后的状态 回调
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    switch (result) {
        case MFMailComposeResultCancelled:
            NSLog(@"邮件取消");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"邮件保存");
            break;
        case MFMailComposeResultSent:
            NSLog(@"邮件发送");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"邮件失败");
            break;
            
        default:
            break;
    }
    //模态跳转返回
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    switch (result) {
        case MessageComposeResultCancelled:
            NSLog(@"发送取消");
            break;
        case MessageComposeResultSent:
            NSLog(@"ok");
            break;
        case MessageComposeResultFailed:
            NSLog(@"no");
            break;
            
        default:
            break;
    }
    //最后要模态跳转返回
    [controller dismissViewControllerAnimated:YES completion:nil];
}

- (void)loadNearApps {
    
    NSString *url = [NSString stringWithFormat:kNearAppUrl, 116.344539, 40.034346];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *modelArray = [[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil] objectForKey:@"applications"];
        for (NSDictionary *nearModel in modelArray) {
            NearApplicationModel *model = [NearApplicationModel new];
            [model setValuesForKeysWithDictionary:nearModel];
            [_nearsArray addObject:model];
        }
        [self refreshNear];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@", [error description]);
    }];
    
}

- (void)refreshNear {
    UIImageView *nearImgView = [[UIImageView alloc] initWithFrame:CGRectMake(minX(_detailImgView), maxY(_detailImgView) + 10, widthFromFrame(_detailImgView.frame), 100)];
    nearImgView.userInteractionEnabled = YES;
    nearImgView.image = [[UIImage imageNamed:@"appdetail_recommend"] stretchableImageWithLeftCapWidth:10 topCapHeight:20];
    [_bottomScrollView addSubview:nearImgView];
    
    _nearsScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(25, 30, widthFromFrame(nearImgView.frame) - 50, 57)];
    _nearsScrollView.delaysContentTouches = NO;
    [nearImgView addSubview:_nearsScrollView];
    for (int i = 0; i < _nearsArray.count; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = 4000 + i;
        btn.frame = CGRectMake(i * 57 + i * 25, 0, 57, 57);
        btn.layer.cornerRadius = 9;
        btn.clipsToBounds = YES;
        [btn sd_setImageWithURL:[NSURL URLWithString:[_nearsArray[i] iconUrl]] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(nearAppBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_nearsScrollView addSubview:btn];
    }
    
}

- (void)nearAppBtnClick:(UIButton *)button {
    DetailViewController *viewC = [[DetailViewController alloc] init];
    viewC.applicationId = [_nearsArray[button.tag - 4000] applicationId];
    
    [self.navigationController pushViewController:viewC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 *  创建导航 按钮
 *
 *  @param bgImgName 背景图片名字
 *  @param frame     button frame
 *  @param title     button title
 *  @param aSelector button action
 *  @param isLeft    是否是左边按钮
 */
- (void)createBarButtonItemWithBackground:(NSString *)bgImgName
                                    Frame:(CGRect)frame
                                    title:(NSString *)title
                                aSelector:(SEL)aSelector
                                   isLeft:(BOOL)isLeft {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, widthFromFrame(frame),heightFromFrame(frame));
    [btn setBackgroundImage:[UIImage imageNamed:bgImgName] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn setTitle:title forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    if (aSelector && [self respondsToSelector:aSelector]) {
        [btn addTarget:self action:aSelector forControlEvents:UIControlEventTouchUpInside];
    }
    
    UIBarButtonItem *barBtnItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    if (isLeft) {
        self.navigationItem.leftBarButtonItem = barBtnItem;
    } else {
        self.navigationItem.rightBarButtonItem = barBtnItem;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
//





































//
