//
//  FreeTabBarController.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "FreeTabBarController.h"
#import "UIView+Common.h"
#import "AppListViewController.h"
#import "FreeAllDefine.h"

@interface FreeTabBarController ()

@end

@implementation FreeTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createViewControllers];
//    [self createLanchAnimation];
}

/**
 *  创建 Viewcontroller
 */
- (void)createViewControllers {
    NSArray *urlArray = @[kLimitUrl, kReduceUrl,kFreeUrl, kSubjectUrl, kHotUrl];
    NSArray *categoryAry = @[kLimitType, kReduceType, kFreeType, kSubjectType, kHotType];
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"Controllers" ofType:@"plist"];
    
    NSArray *aryTypes = [[NSArray alloc] initWithContentsOfFile:plistPath];
    
    NSMutableArray *aryTab = [NSMutableArray array];
    NSInteger i = 0;
    for (NSDictionary *vcDict in aryTypes) {
        Class cls = NSClassFromString(vcDict[@"className"]);
        AppListViewController *listVc = [[cls alloc] init];
        UINavigationController *listNav = [[UINavigationController alloc] initWithRootViewController:listVc];
        listVc.categoryViewType = categoryAry[i];
        // 传入 URL
        listVc.requestURL = [urlArray objectAtIndex:i];
        listVc.title = vcDict[@"title"];
        
        listVc.tabBarItem.image = [UIImage imageNamed:vcDict[@"iconName"]];
        listVc.tabBarItem.selectedImage = [[UIImage imageNamed:vcDict[@"iconSelectName"]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        [aryTab addObject:listNav];
        
        i ++;
    }
    
    self.viewControllers = aryTab;
    
}

/**
 * 启动广告
 */
- (void)createLanchAnimation {
    UIImageView *splshImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenWidth(), screenHeight())];
    NSString *splshImagePath = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"Default%d@2x", arc4random_uniform(7) + 1] ofType:@"png"];
    splshImageView.image = [[UIImage alloc] initWithContentsOfFile:splshImagePath];
    
    [self.view addSubview:splshImageView];
    
    [UIView animateWithDuration:3 animations:^{
        splshImageView.alpha = 0.0;
    } completion:^(BOOL finished) {
        [splshImageView removeFromSuperview];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
