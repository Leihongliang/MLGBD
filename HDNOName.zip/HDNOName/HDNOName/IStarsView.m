//
//  IStarsView.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "IStarsView.h"

@implementation IStarsView {
    UIImageView *_foregroundView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self customViews];
    }
    return self;
}

- (void)customViews {
    UIImageView *backgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 65, 23)];
    backgroundView.image = [UIImage imageNamed:@"StarsBackground"];
    [self addSubview:backgroundView];
    
    _foregroundView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _foregroundView.image = [UIImage imageNamed:@"StarsForeground"];
    // 此方法防止图片拉伸变形
    _foregroundView.contentMode = UIViewContentModeLeft;
    _foregroundView.clipsToBounds = YES;
    [self addSubview:_foregroundView];
}

- (void)setLevel:(double)level {
    _foregroundView.frame = CGRectMake(0, 0, 65 * level/5.0, 23);
}

@end
