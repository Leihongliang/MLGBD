//
//  PhotoViewController.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/27.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "BaseViewController.h"
#import "DetailModel.h"

@interface PhotoViewController : BaseViewController

@property (nonatomic, assign) NSInteger photoIndex;

@property (nonatomic, strong) NSArray<PhotoModel> *photos;

@end
