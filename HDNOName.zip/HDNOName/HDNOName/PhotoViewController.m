//
//  PhotoViewController.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/27.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "PhotoViewController.h"
#import "UIView+Common.h"
#import <UIImageView+WebCache.h>
#import <MBProgressHUD.h>

@interface PhotoViewController ()

@end

@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = [UIColor blackColor];
    [self addTitleWithName:@"大图"];
    [self createScrollView];
}

- (void)createScrollView {
    UIScrollView *photosScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, screenWidth() + 20, screenHeight())];
    photosScrollView.center = self.view.center;
    photosScrollView.pagingEnabled = YES;
    photosScrollView.contentOffset = CGPointMake(_photoIndex * widthFromFrame(photosScrollView.frame), 0);
    photosScrollView.contentSize = CGSizeMake(_photos.count * widthFromFrame(photosScrollView.frame), heightFromFrame(photosScrollView.frame));
    
    [self.view addSubview:photosScrollView];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    for (int i = 0; i < _photos.count; i ++) {
        
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectZero];
        imgView.tag = 1000 + i;
        [photosScrollView addSubview:imgView];
        
        
        [imgView sd_setImageWithURL:[NSURL URLWithString:[_photos[i] originalUrl]] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            imgView.frame = CGRectMake(0, 0, screenWidth(), image.size.height * screenWidth() / image.size.width);
            imgView.center = CGPointMake(self.view.center.x + (imgView.tag - 1000) * (screenWidth() + 20), self.view.center.y - 64);
            if (imgView.tag == 1000 + _photos.count - 1) {
                [MBProgressHUD hideHUDForView:self.view animated:YES];
            }
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
