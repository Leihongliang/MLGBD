//
//  SearchViewController.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _tableView.tableHeaderView = nil;
    
}

/**
 *  初始化 导航按钮
 */
- (void)initBarButtonItems {
    [self createBarButtonItemWithBackground:@"buttonbar_action" Frame:CGRectMake(0, 0, 43, 30) title:@"返回" aSelector:@selector(buttonActionLeft:) isLeft:YES];
}

// 导航左键点击方法
- (void)buttonActionLeft:(UIButton *)button {
//    [self.navigationController popToRootViewControllerAnimated:YES];
    NSArray *aryViewControllers = self.navigationController.viewControllers;
    
    [self.navigationController popToViewController:aryViewControllers[0] animated:YES];
}

- (void)prepareLoadData:(BOOL)isMore {
    NSString *url = @"";
    NSInteger page = 1;
    if (isMore) {
        page = _dataAry.count / 10 + 1;
    }
    
    url = [NSString stringWithFormat:self.requestURL, page, _searchText];
    
    [self lodingData:url isMore:isMore];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
