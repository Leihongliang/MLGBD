//
//  SetViewController.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/27.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "SetViewController.h"
#import "UIView+Common.h"

@interface SetViewController () {
    NSArray *_classNames;
}

@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self showUI];
}
- (void)showUI {
    self.title = @"设置";
    [self addTitleWithName:@"设置"];
    [self createBarButtonItemWithBackground:@"buttonbar_back" Frame:CGRectMake(0, 0, 45, 30) title:@"返回" aSelector:@selector(buttonClick:) isLeft:YES];
    self.view.backgroundColor = [UIColor colorWithRed:226/255.0 green:226/255.0 blue:226/255.0 alpha:1];
    _classNames = [[NSArray alloc]initWithObjects:@"MySettingViewController",@"MyAttentionViewController",@"MyUserViewController",@"MyFavoriteViewController",@"MyDownloadViewController",@"MyCommentViewController",@"MyHelpViewController",@"CandouViewController",nil];
    NSArray *imageNames = @[@"account_setting",@"account_favorite",@"account_user",@"account_collect",@"account_download",@"account_comment",@"account_help",@"account_candou"];
    NSArray *titles = @[@"我的设置",@"我的关注",@"我的账户",
                        @"我的收藏",@"我的下载",@"我的评论",
                        @"我的帮助",@"蚕豆应用"];
    
    //横向的间隔
    CGFloat wSpace = (screenWidth() - 3*57)/4;
    
    //纵向的间隔
    CGFloat hSpace = (screenHeight()-64-49 - 3*57)/4;
    for (int i = 0; i<imageNames.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = 101+i;
        [btn setImage:[UIImage imageNamed:imageNames[i]] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        btn.layer.masksToBounds = YES;
        btn.layer.cornerRadius = 8;
        //九宫格坐标的小算法:(横坐标:i%横向显示个数的最大值;纵坐标:i/纵向的个数的最大值)
        [btn setFrame:CGRectMake(wSpace +(i%3)*(57+wSpace),hSpace +(i/3)*(hSpace+57), 57,57)];
        [self.view addSubview:btn];
        
        //创建label
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(wSpace+(i%3)*(57+wSpace),hSpace+57 + (i/3)*(hSpace+57), 57, 20)];
        label.text = titles[i];
        
        label.font = [UIFont systemFontOfSize:12];
        label.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:label];
        
        
    }
}

- (void)buttonClick:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - 按钮触发的函数
- (void)btnClicked:(UIButton *)button{
    Class vcClass = NSClassFromString(_classNames[button.tag - 101]);
    BaseViewController *vc = [[vcClass alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
