//
//  SubItems.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubjectModel.h"

@interface SubItems : UIView

@property (nonatomic, strong) Apps *model;

@end
