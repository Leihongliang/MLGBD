//
//  SubItems.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "SubItems.h"
#import "IStarsView.h"
#import "UIView+Common.h"
#import <UIImageView+WebCache.h>

@interface SubItems() {
    UIImageView *_appIcon;
    UILabel *_appTitle;
    UIImageView *_imgViewComment;
    UILabel *_labelComment;
    UIImageView *_imgViewDown;
    UILabel *_labelDownCount;
    IStarsView *_istars;
    UILabel *_labelSeparate;
}

@end

@implementation SubItems

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.userInteractionEnabled = YES;
        [self createItems];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _appIcon.frame = CGRectMake(0, 5, 45, 45);
    
    _appTitle.frame = CGRectMake(15 + maxX(_appIcon), 2, widthFromFrame(self.frame) - 57 - 15 - 10, 13);
    
    _imgViewComment.frame = CGRectMake(minX(_appTitle) + 3, maxY(_appTitle) + 4, 13, 9);
    
    _labelComment.frame = CGRectMake(maxX(_imgViewComment) + 2, minY(_imgViewComment), 50, 9);
    
    _imgViewDown.frame = CGRectMake(widthFromFrame(self.frame) - 70, minY(_imgViewComment), 13, 9);
    
    _labelDownCount.frame = CGRectMake(maxX(_imgViewDown) + 2, minY(_labelComment), 50, 9);
    
    _istars.frame = CGRectMake(minX(_imgViewComment), maxY(_imgViewComment) + 3, 65, 23);
    
    _labelSeparate.frame = CGRectMake(0, maxY(_istars) + 1, widthFromFrame(self.frame), 1);
}

- (void)setModel:(Apps *)model {
    _model = model;
    [self reloadData];
}

- (void)reloadData {
    [_appIcon sd_setImageWithURL:[NSURL URLWithString:_model.iconUrl] placeholderImage:[UIImage imageNamed:@"icon"]];
    
    _appTitle.text = _model.name;
    
    _labelComment.text = _model.ratingOverall;
    
    _labelDownCount.text = _model.downloads;
    
    [_istars setLevel:[_model.starOverall doubleValue]];
}

- (void)createItems {
    _appIcon = [UIImageView new];
    _appIcon.layer.cornerRadius = 6;
    _appIcon.layer.borderWidth = 1;
    _appIcon.layer.borderColor = [[[UIColor whiteColor] colorWithAlphaComponent:0.9] CGColor];
    _appIcon.clipsToBounds = YES;
    [self addSubview:_appIcon];
    
    _appTitle = [UILabel new];
    _appTitle.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1];
    _appTitle.font = [UIFont boldSystemFontOfSize:13];
    [self addSubview:_appTitle];
    
    _imgViewComment = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"topic_Comment"]];
    [self addSubview:_imgViewComment];
    
    _labelComment = [UILabel new];
    _labelComment.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1];
    _labelComment.font = [UIFont boldSystemFontOfSize:9];
    [self addSubview:_labelComment];
    
    _imgViewDown = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"topic_Download"]];
    [self addSubview:_imgViewDown];
    
    _labelDownCount = [UILabel new];
    _labelDownCount.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1];
    _labelDownCount.font = [UIFont boldSystemFontOfSize:9];
    [self addSubview:_labelDownCount];
    
    _istars = [IStarsView new];
    [self addSubview:_istars];
    
    _labelSeparate = [UILabel new];
    _labelSeparate.layer.borderWidth = 1;
    _labelSeparate.layer.borderColor = [[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1] CGColor];
    [self addSubview:_labelSeparate];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
