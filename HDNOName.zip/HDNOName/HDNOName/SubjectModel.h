//
//  SubjectModel.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/23.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "JSONModel.h"


@protocol Apps
@end
@interface Apps : JSONModel

@property (nonatomic, copy) NSString<Optional> *applicationId;
@property (nonatomic, copy) NSString<Optional> *downloads;
@property (nonatomic, copy) NSString<Optional> *iconUrl;
@property (nonatomic, copy) NSString<Optional> *name;
@property (nonatomic, copy) NSString<Optional> *ratingOverall;
@property (nonatomic, copy) NSString<Optional> *starOverall;

@end

@protocol SubjectItems
@end
@interface SubjectItems : JSONModel

@property (nonatomic, copy) NSString<Optional> *title;
@property (nonatomic, copy) NSString<Optional> *date;
@property (nonatomic, copy) NSString<Optional> *desc;
@property (nonatomic, copy) NSString<Optional> *desc_img;
@property (nonatomic, copy) NSString<Optional> *img;
@property (nonatomic, strong) NSArray<Apps> *applications;

@end

@interface SubjectModel : JSONModel

@property (nonatomic, strong) NSArray<SubjectItems> *subject;

@end
