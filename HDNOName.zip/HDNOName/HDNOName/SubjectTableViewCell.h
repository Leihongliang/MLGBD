//
//  SubjectTableViewCell.h
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubjectModel.h"

typedef void(^SubItemBlock)(NSString *appID);

@interface SubjectTableViewCell : UITableViewCell

@property (nonatomic, copy) SubItemBlock subItemBlock;
@property (nonatomic, strong)SubjectItems  *model;

@end
