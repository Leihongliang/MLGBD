//
//  SubjectTableViewCell.m
//  HDNOName
//
//  Created by qianfeng01 on 15/9/24.
//  Copyright (c) 2015年 hanzhiyuan. All rights reserved.
//

#import "SubjectTableViewCell.h"
#import "SubItems.h"
#import <UIImageView+WebCache.h>
#import "UIView+Common.h"

@interface SubjectTableViewCell() {
    UILabel *_titleLabel;
    UILabel *_separatorTitle;
    UIImageView *_pictureTheme;
    SubItems *_subItem1;
    SubItems *_subItem2;
    SubItems *_subItem3;
    SubItems *_subItem4;
    NSMutableArray *_mArySubs;
    
    UIImageView *_pictureCompiler;
    UITextView *_recommendCompiler;
    
}

@end

@implementation SubjectTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _mArySubs = [NSMutableArray array];
        [self createCell];
    }
    return self;
}

- (void)createCell {
    _titleLabel = [UILabel new];
    _titleLabel.font = [UIFont boldSystemFontOfSize:19];
    _titleLabel.textColor = [UIColor colorWithRed:19/255.0 green:19/255.0 blue:19/255.0 alpha:1];
    [self.contentView addSubview:_titleLabel];
    
    _separatorTitle = [UILabel new];
    _separatorTitle.layer.borderWidth = 1;
    _separatorTitle.layer.borderColor = [[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1] CGColor];
    [self.contentView addSubview:_separatorTitle];
    
    _pictureTheme = [UIImageView new];
    _pictureTheme.layer.cornerRadius = 6;
    _pictureTheme.layer.borderColor = [[[UIColor whiteColor] colorWithAlphaComponent:0.9] CGColor];
    _pictureTheme.layer.borderWidth = 1;
    _pictureTheme.clipsToBounds = YES;
    [self.contentView addSubview:_pictureTheme];
       
    for (int i = 0; i < 4; i ++) {
        SubItems *subItem = [SubItems new];
        subItem.hidden = YES;
        subItem.tag = 100 + i;
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapValueChanged:)];
        subItem.gestureRecognizers = @[tapGesture];
        [_mArySubs addObject:subItem];
        [self.contentView addSubview:subItem];
    }
    
    _pictureCompiler = [UIImageView new];
    _pictureCompiler.layer.borderColor = [[[UIColor whiteColor] colorWithAlphaComponent:0.9] CGColor];
    _pictureCompiler.layer.borderWidth = 1;
    _pictureCompiler.layer.cornerRadius = 4;
    _pictureCompiler.clipsToBounds = YES;
    [self.contentView addSubview:_pictureCompiler];
    
    _recommendCompiler = [UITextView new];
    _recommendCompiler.font = [UIFont boldSystemFontOfSize:13];
    _recommendCompiler.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1];
    _recommendCompiler.backgroundColor = [UIColor clearColor];
    _recommendCompiler.editable = NO;
    
    [self.contentView addSubview:_recommendCompiler];
}

/**
 *  获取对应手势的父视图
 *
 *  @param gesture
 */
- (void)tapValueChanged:(UIGestureRecognizer *)gesture {
    SubItems *item = (SubItems *)[gesture view];
    NSInteger index = item.tag - 100;
    if (_subItemBlock) {
    
        NSString *appIDStr = [_model.applications[index] applicationId];
        
        _subItemBlock(appIDStr);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _titleLabel.frame = CGRectMake(15, 10, widthFromFrame(self.frame), 22);
    
    _separatorTitle.frame = CGRectMake(5, maxY(_titleLabel) + 10, widthFromFrame(self.frame) - 10, 1);
    
    _pictureTheme.frame = CGRectMake(minX(_titleLabel), maxY(_separatorTitle) + 10, 130, 200);
    
    CGRect rect = CGRectMake(maxX(_pictureTheme) + 10, minY(_pictureTheme) - 5, widthFromFrame(self.frame) - 100 - 65, 55);
    for (int i = 0; i < 4; i ++) {
        SubItems *item = [_mArySubs objectAtIndex:i];
        item.frame = rect;
        
        rect = CGRectMake(rect.origin.x, rect.origin.y + 56, rect.size.width, rect.size.height);
    }
    
    _pictureCompiler.frame = CGRectMake(minX(_pictureTheme), maxY(_pictureTheme) + 25, 57, 57);
    
    _recommendCompiler.frame = CGRectMake(maxX(_pictureCompiler) + 10, minY(_pictureCompiler), widthFromFrame(self.frame) - 60 - 53, 57);
}

- (void)setModel:(SubjectItems *)model {
    _model = model;
    [self reloadData];
}

- (void)reloadData {
    _titleLabel.text = _model.title;
    
    [_pictureTheme sd_setImageWithURL:[NSURL URLWithString:_model.img] placeholderImage:[UIImage imageNamed:@"Default3"]];
    
    for (int i = 0; i < 4; i ++) {
        if (i < _model.applications.count) {
            [[_mArySubs objectAtIndex:i] setHidden:NO];
        } else {
            [[_mArySubs objectAtIndex:i] setHidden:YES];
        }
    }
    
    int i = 0;
    for (Apps *app in _model.applications) {
        SubItems *ap = [_mArySubs objectAtIndex:i];
        ap.model = app;
        i ++;
    }
    
    [_pictureCompiler sd_setImageWithURL:[NSURL URLWithString:_model.desc_img] placeholderImage:[UIImage imageNamed:@"icon"]];
    _recommendCompiler.text = _model.desc;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
//





































//
