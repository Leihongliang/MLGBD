//
//  MySettingViewController.m
//  LimitFree
//
//  Created by LZXuan on 15-4-15.
//  Copyright (c) 2015年 LZXuan. All rights reserved.
//

#import "MySettingViewController.h"
#import "UIView+Common.h"
#import "DBManager.h"
#import "JWCache.h"

@interface MySettingViewController ()<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_dataArr;
}
@end

@implementation MySettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addTitleWithName:@"设置"];
    self.view.backgroundColor = [UIColor whiteColor];
    [self dataInit];
    [self creatTableView];
}

- (void)creatTableView {
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenWidth(), screenHeight()-64-49) style:UITableViewStyleGrouped];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [self.view addSubview:_tableView];
}

- (void)dataInit {
    _dataArr = [[NSMutableArray alloc] init];
    NSArray *arr1 = @[@"推送设置",@"开启推送通知",@"开启关注通知",@"清除缓存"];
    [_dataArr addObject:arr1];
    NSArray *arr2 = @[@"推荐爱限免",@"官方推荐",@"官方微博"];
    [_dataArr addObject:arr2];
    
    [_tableView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _dataArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_dataArr[section]count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    if (indexPath.section == 0) {
        if (indexPath.row == 1||indexPath.row == 2 ) {
            UISwitch *sw = [[UISwitch alloc] initWithFrame:CGRectMake(200, 0, 100, 30)];
            [sw addTarget:self action:@selector(swClick:) forControlEvents:UIControlEventValueChanged];
            sw.tag = indexPath.row+1001;
            //粘贴到cell 的contentView上
            [cell.contentView addSubview:sw];
        }
    }
    cell.textLabel.text = _dataArr[indexPath.section][indexPath.row];
    return cell;
}
//开关按钮
- (void)swClick:(UISwitch *)sw {
    
}

//cell 选中
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0 && indexPath.row == 3) {
        BOOL isOk = [[DBManager sharedManager] dropTable];
        [JWCache resetCache];
        if (isOk) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"删除成功" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
        }
    }
}

@end
